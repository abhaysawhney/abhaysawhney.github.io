#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>
#include "deck.h"

using namespace std;

static void welcomeSign(){
    cout << "   $$$$$$\\  $$\\       $$\\                          $$\\                $$$$$$\\                      $$\\                     " << endl << "  $$  __$$\\ $$ |      $$ |                         $  |              $$  __$$\\                     \\__|                    " << endl << "  $$ /  $$ |$$$$$$$\\  $$$$$$$\\   $$$$$$\\  $$\\   $$\\\\_/$$$$$$$\\       $$ /  \\__| $$$$$$\\   $$$$$$$\\ $$\\ $$$$$$$\\   $$$$$$\\  " << endl << "  $$$$$$$$ |$$  __$$\\ $$  __$$\\  \\____$$\\ $$ |  $$ | $$  _____|      $$ |       \\____$$\\ $$  _____|$$ |$$  __$$\\ $$  __$$\\ " << endl << "  $$  __$$ |$$ |  $$ |$$ |  $$ | $$$$$$$ |$$ |  $$ | \\$$$$$$\\        $$ |       $$$$$$$ |\\$$$$$$\\  $$ |$$ |  $$ |$$ /  $$ |" << endl << "  $$ |  $$ |$$ |  $$ |$$ |  $$ |$$  __$$ |$$ |  $$ |  \\____$$\\       $$ |  $$\\ $$  __$$ | \\____$$\\ $$ |$$ |  $$ |$$ |  $$ |" << endl << "  $$ |  $$ |$$$$$$$  |$$ |  $$ |\\$$$$$$$ |\\$$$$$$$ | $$$$$$$  |      \\$$$$$$  |\\$$$$$$$ |$$$$$$$  |$$ |$$ |  $$ |\\$$$$$$  |" << endl << "  \\__|  \\__|\\_______/ \\__|  \\__| \\_______| \\____$$ | \\_______/        \\______/  \\_______|\\_______/ \\__|\\__|  \\__| \\______/ " << endl << "                                          $$\\   $$ |                                                                       " << endl << "                                          \\$$$$$$  |                                                                       " << endl << "                                           \\______/                                                                        "<< endl;
}

static string printCard(int x) {
    if (x < 10) {
        ostringstream ss;
        ss << x;
        return ss.str();
    }

    if (x > 10)
        return "A";

    return "Face";
}

static bool choose() {
    char choice;
takechoice:

    cout << "Hit or Stand? (Enter H or S)" << endl;
    cin >> choice;
    if (choice != 'H' && choice != 'S') {
        cout << "Sorry, try again. ";
        goto takechoice;
    }

    return (choice == 'H');
}

static bool playBJ() {

    bool playing = true;
    int dealScore = 0, playScore = 0, dealAces, playAces = 0, dealCard, playCard;
    string dealCards = "Dealer's Cards:";
    string playCards = "Your Cards:";
    string choice;


    Deck dealDeck = Deck();
    Deck playDeck = Deck();


    //DEAL FIRST TWO CARDS
    for (int i = 0; i < 2; i++) {
        dealCard = dealDeck.getCard();
        dealScore += dealCard;
        dealCards += " " + printCard(dealCard);
        if (dealCard == 11)
            dealAces++;

        playCard = playDeck.getCard();
        playScore += playCard;
        playCards += " " + printCard(playCard);
        if (playCard == 11)
            playAces++;
    }

    cout << "Dealer Score: " << dealScore << "   " << dealCards << endl;

    //CHECK FOR BLACKJACKS

    if (dealScore == 21) {
        cout << "Dealer Blackjack!";
        return false;
    }

    if (playScore == 21) {
        cout << "Your Score: " << playScore << "  " << playCards << endl;
        cout << "Blackjack!";
        return true;
    }

    //PLAYER TURN 

    while (playing) {

        cout << "Your Score: " << playScore << "  " << playCards << endl;

        if (choose()) {
            //TAKE CARD
            playCard = playDeck.getCard();
            playScore += playCard;
            playCards += " " + printCard(playCard);
            if (playCard == 11)
                playAces++;

checkscore:
            if (playScore > 21) {
                if (playAces > 0) {
                    playScore -= 10;
                    playAces--;
                    goto checkscore;
                }
                cout << "Your Score: " << playScore << "  " << playCards << endl;
                goto losegame;
            }

        } else
            playing = false;
    }

    //DEALER TURN
    while (dealScore <= 16) {
        dealCard = dealDeck.getCard();
        dealScore += dealCard;
        dealCards += " " + printCard(dealCard);
        if (dealCard == 11)
            dealAces++;

checkdeal:
        if (dealScore > 21) {
            if (dealAces > 0) {
                dealScore -= 10;
                dealAces--;
                goto checkdeal;
            }
            cout << "Dealer Score: " << dealScore << "  " << dealCards << endl;
            goto wingame;
        }
    }


    //VERDICT

    cout << "Dealer Score: " << dealScore << "  " << dealCards << endl;
    cout << "Your Score: " << playScore << "  " << playCards << endl;


    if (playScore > dealScore) {

wingame:
        cout << "Congratulations!" << endl << endl;
        return true;
    }

losegame:
    cout << "Too bad!" << endl << endl;
    return false;
}

int main(int argc, char** argv) {
    
    welcomeSign();
    
    cout << "Welcome to the casino! Let's get you started with $1,000,000." << endl << endl;

    int money = 1000000, bet;
    bool won;
    int games = 0, gamesWon = 0;

    while (money > 0) {

takebet:
        cout << "Enter your bet amount, or enter 0 to quit" << endl;
        cin >> bet;

        if (bet <= 0)
            break;

        if (bet > money) {
            cout << "Can't bet that much! ";
            goto takebet;
        }

        won = playBJ();
        games++;

        if (won) {
            gamesWon++;
            money += bet;
        } else
            money -= bet;

        cout << "Money: " << money << "   Games Played: " << games << "   Games Won: " << gamesWon << endl << endl;

    }

    cout << endl << "Thanks for playing!" << endl;

    return 0;
}