#ifndef DECK_H
#define DECK_H

class Deck{
    
    int* cards;
    int remaining;
    
    public:
        
        Deck();
        int getCard();
        void showCards();
        
    
};


#endif /* DECK_H */

