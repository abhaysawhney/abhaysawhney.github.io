
#include <iostream>
#include <algorithm>
#include "deck.h"

using namespace std;


Deck::Deck(){
    
    remaining = 52;
    cards = new int[52];
    
    //create deck
    for(int i = 0; i < 36; i++)
        cards[i] = 2 + i/4;
    for(int i = 36; i < 48; i++)
        cards[i] = 10;
    for(int i = 48; i < 52; i++)
        cards[i] = 11;
        
    
    //shuffle deck
    random_shuffle(&cards[0], &cards[52]);
}

int Deck::getCard(){
    
    remaining--;
    return cards[remaining];
}

void Deck::showCards(){
    
    for(int i = 0; i < remaining; i++)
        cout << cards[i] << " ";
    
    cout << endl;
}